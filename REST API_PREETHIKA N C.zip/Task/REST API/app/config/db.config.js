//Configuration of DB
module.exports = {
  HOST: "localhost",
  USER: "root",
  PASSWORD: "Ha11yPo11er@#1980",
  DB: "tutorialdb"
};